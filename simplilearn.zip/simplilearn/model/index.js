const mongoose = require("mongoose");

//mongoClient.connect(url, {useUnifiedTopology: true },(err1,client)=>{
mongoose.connect("mongodb://localhost:27017/simplilearn", { useUnifiedTopology: true } ,  (error)=>{
    if(!error)
    {
        console.log("success");
    }
    else
    {
        console.log("Error connecting to database.")
    }
});
const Course = require("./course.model");