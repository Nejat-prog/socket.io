const  express = require("express");
const router = express.Router();
const courseModel = mongoose.model("Course")

router.get("/add", ()=>{
    res.render("add-course")
})

router.post("/add", ()=>{
    res.render("add-course")

     console.log(req.body);

     var course = new courseModel();
    course.courseName = res.body.courseName;
    course.courseDuration = red.body.courseDuration;
    course.courseFees = red.body.courseFees;
    course.courseId = Math.ceil(Math.ceil(Math.random() * 10000000) + "";
    course.save((err,docs)=>{
        if(!err)
        {
         // res.redirect("/course/list")
         res.json({ message : "successfull",status: "" })
        }
        else
        {
            res.send("Error occured");

        }

    })

   //  res.render("add-course");
    

router.get("/List", (req, res)=>{

      
    
    //getting
      courseModel.find((err,doc)=>{
        if(!err)
        {
           console.log(docs);
            res.send("course Controller")
        }
    })
    res.send("List", { data : docs })
});

module.exports = router;
