const connection = require("./model");
const express = require("express");
const application =express();
const path = require("path");
const expressHandlebars = require("express-handelbare");
const bodyparser = require("body-parser");

const courseController = require("./controllers/course")


application.use(bodyparser.urlencoded({
    extended : true
}));
application.set('views', path.join(__dirname, "/views/"))

application.engine("hbs",expressHandlerbars({
    extname : "hbs",
    defaultLayout : "mainlayout",
    layoutsDir:__dirname+ "views/layouts"

}));
application.set("view engine", "hbs")
application.get("/", (res, res)=>{
   // res.send('<h1>Hello world>')
   res.render("index",{})
})

application.use("/course",CourseController)

application.listen("3000", ()=>{
    console.log("server started");
});